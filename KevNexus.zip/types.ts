
export interface NavItem {
  label: string;
  href: string;
}

export interface Project {
  title: string;
  description: string;
  tags: string[];
  github?: string;
  demo?: string;
  image: string;
}

export interface Skill {
  name: string;
  level: number;
  category: 'Frontend' | 'Backend' | 'DevOps' | 'AI';
}

export interface AIResponse {
  analysis: string;
  suggestions: string[];
  optimizedCode?: string;
}
