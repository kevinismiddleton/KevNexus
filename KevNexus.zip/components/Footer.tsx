
import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-20 px-6 border-t border-white/5 bg-slate-950">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-12 mb-16">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-2 mb-4 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform shadow-[0_0_15px_rgba(79,70,229,0.5)]">
                <span className="text-white font-bold text-lg leading-none">K</span>
              </div>
              <span className="text-2xl font-bold tracking-tight">KevNexus</span>
            </div>
            <p className="text-slate-500 text-sm max-w-xs leading-relaxed">
              Precision-engineered software solutions and high-performance system architectures.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-end gap-6">
             <div className="text-xs font-bold uppercase tracking-[0.2em] text-indigo-400/60 mb-2">Connect with the Architect</div>
             <div className="flex flex-wrap justify-center gap-6">
                <a 
                  href="https://instagram.com/mingvin_" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="group flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-xl transition-all"
                >
                  <span className="text-slate-400 group-hover:text-indigo-400 text-sm font-semibold">Instagram</span>
                </a>
                <a 
                  href="https://github.com/kevinismiddleton" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="group flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-xl transition-all"
                >
                  <span className="text-slate-400 group-hover:text-indigo-400 text-sm font-semibold">GitHub</span>
                </a>
             </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4 text-slate-500 text-xs font-medium">
            <p>© {currentYear} KevNexus.</p>
            <div className="w-1 h-1 rounded-full bg-slate-800"></div>
            <p>Built for performance.</p>
          </div>

          <div className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-white/5">
            <span className="text-slate-500 text-xs font-semibold uppercase tracking-widest">Crafted & Designed by</span>
            <a 
              href="https://instagram.com/mingvin_" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-white font-bold text-sm hover:text-indigo-400 transition-colors flex items-center gap-1"
            >
              Kevin
              <span className="text-[10px] text-indigo-500/50">(@mingvin_)</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
