
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeCode(code: string, language: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `You are an expert senior software engineer. Analyze this ${language} code for bugs, security issues, and performance bottlenecks. Provide a concise technical review.\n\nCODE:\n${code}`,
      config: {
        thinkingConfig: { thinkingBudget: 2000 },
        temperature: 0.7,
      },
    });

    return response.text || "Unable to analyze code at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "An error occurred while communicating with the AI. Please try again.";
  }
}

export async function optimizeCode(code: string, language: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `You are a high-performance systems engineer. Rewrite this ${language} code to be more efficient, clean, and modern. Maintain the original logic but improve performance.\n\nCODE:\n${code}`,
      config: {
        thinkingConfig: { thinkingBudget: 2000 },
        temperature: 0.2,
      },
    });

    return response.text || "Unable to optimize code.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error during optimization.";
  }
}
