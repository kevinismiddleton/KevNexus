
import React from 'react';

const projects = [
  {
    title: "Vortex OS",
    description: "A custom real-time operating system kernel written in Rust for specialized edge computing devices.",
    tags: ["Rust", "Assembly", "Low-Level"],
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "NeuralStream",
    description: "High-throughput data pipeline processing 1M+ events/sec using Go and Apache Kafka with ML classification.",
    tags: ["Go", "Kafka", "Machine Learning"],
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc51?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "CryptoGate v2",
    description: "Distributed ledger gateway for institutional liquidity providers with <5ms latency requirements.",
    tags: ["C++", "gRPC", "Web3"],
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800"
  }
];

const Projects: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
        <div>
          <h2 className="text-4xl font-bold mb-4 tracking-tight">Technical <span className="gradient-text">Showcase</span></h2>
          <p className="text-slate-400 max-w-md">Selected engineering feats focusing on scale, performance, and robustness.</p>
        </div>
        <a href="https://github.com/kevinismiddleton" target="_blank" rel="noopener noreferrer" className="text-indigo-400 font-bold hover:underline">
          Browse All Repositories →
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, idx) => (
          <div key={idx} className="group glass rounded-3xl overflow-hidden border-white/5 hover:border-indigo-500/30 transition-all hover:-translate-y-2">
            <div className="h-48 overflow-hidden relative">
              <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent"></div>
            </div>
            <div className="p-8">
              <div className="flex gap-2 mb-4">
                {project.tags.map(tag => (
                  <span key={tag} className="text-[10px] uppercase font-bold tracking-widest px-2 py-1 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    {tag}
                  </span>
                ))}
              </div>
              <h3 className="text-xl font-bold mb-3">{project.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">{project.description}</p>
              <div className="flex items-center gap-4">
                <button className="text-xs font-bold text-white bg-indigo-600/20 px-4 py-2 rounded-lg border border-indigo-500/30 hover:bg-indigo-600/40 transition-all">Details</button>
                <button className="text-xs font-bold text-slate-400 hover:text-white transition-colors">GitHub</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
