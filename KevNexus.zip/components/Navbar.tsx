
import React from 'react';

interface NavbarProps {
  activeSection: string;
}

const Navbar: React.FC<NavbarProps> = ({ activeSection }) => {
  const navItems = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'AI Tools', href: '#ai', id: 'ai' },
    { label: 'Projects', href: '#projects', id: 'projects' },
    { label: 'Expertise', href: '#skills', id: 'skills' },
  ];

  return (
    <nav className="fixed top-0 left-0 w-full z-50 px-4 md:px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between glass rounded-2xl px-6 md:px-8 py-3">
        <div className="flex items-center gap-2 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform shadow-[0_0_15px_rgba(79,70,229,0.5)]">
            <span className="text-white font-bold text-lg leading-none">K</span>
          </div>
          <span className="text-xl font-bold tracking-tight hidden sm:block">KevNexus</span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.id}
              href={item.href}
              className={`text-sm font-medium transition-colors hover:text-indigo-400 ${
                activeSection === item.id ? 'text-indigo-400' : 'text-slate-400'
              }`}
            >
              {item.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <a 
            href="https://github.com/kevinismiddleton" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm font-medium px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 transition-all shadow-[0_0_20px_rgba(79,70,229,0.3)] hover:scale-105"
          >
            Hire Kevin
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
