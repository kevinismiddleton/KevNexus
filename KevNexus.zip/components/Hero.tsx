
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative pt-32 pb-20 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold uppercase tracking-widest mb-8 animate-fade-in">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
          </span>
          Next-Gen Engineering by Kevin
        </div>
        
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tighter mb-8 leading-[1.1]">
          Building the <span className="gradient-text">Future</span> of <br className="hidden md:block" />
          Scalable Software.
        </h1>
        
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mb-12 leading-relaxed">
          I am Kevin, a specialized full-stack engineer focusing on high-performance 
          distributed systems, real-time AI integration, and world-class 
          user experiences.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-6 mb-20">
          <a href="#projects" className="w-full sm:w-auto px-8 py-4 bg-white text-slate-950 font-bold rounded-2xl hover:bg-slate-200 transition-colors">
            View My Work
          </a>
          <a href="#ai" className="w-full sm:w-auto px-8 py-4 glass border-white/10 font-bold rounded-2xl hover:bg-white/5 transition-colors">
            Try Codex AI
          </a>
        </div>

        {/* Mock Code Editor Visual */}
        <div className="w-full max-w-4xl mx-auto glass rounded-2xl border-white/10 overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between px-4 py-3 bg-white/5 border-b border-white/5">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
            </div>
            <div className="text-xs text-slate-500 mono tracking-wider">production_kernel.rs</div>
            <div className="w-8"></div>
          </div>
          <div className="p-6 md:p-10 text-left overflow-x-auto">
            <pre className="mono text-sm md:text-base leading-relaxed text-indigo-300">
              <code>{`#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let config = Config::load_from_env()?;
    let engine = KevNexusEngine::initialize(config).await?;

    info!("Starting KevNexus core service on port 8080...");
    
    // Spawn high-priority worker threads
    let handle = tokio::spawn(async move {
        engine.run_heavy_computations().await
    });

    handle.await??;
    Ok(())
}`}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
