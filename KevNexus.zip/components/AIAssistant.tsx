
import React, { useState } from 'react';
import { analyzeCode, optimizeCode } from '../services/geminiService';

const AIAssistant: React.FC = () => {
  const [code, setCode] = useState('// Paste your code here to see the magic...');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState('typescript');

  const handleAnalyze = async () => {
    if (!code.trim() || code === '// Paste your code here to see the magic...') return;
    setLoading(true);
    setResult('Engine starting... analyzing syntax and performance patterns.');
    const analysis = await analyzeCode(code, language);
    setResult(analysis);
    setLoading(false);
  };

  const handleOptimize = async () => {
    if (!code.trim() || code === '// Paste your code here to see the magic...') return;
    setLoading(true);
    setResult('Computing optimizations... rewriting for peak efficiency.');
    const optimized = await optimizeCode(code, language);
    setResult(optimized);
    setLoading(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
      <div className="glass rounded-3xl border-white/10 overflow-hidden flex flex-col h-[600px]">
        <div className="px-6 py-4 bg-white/5 border-b border-white/5 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-widest">Source Input</h3>
          <select 
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-slate-800 border-none text-xs rounded-lg px-2 py-1 outline-none text-indigo-300 focus:ring-1 focus:ring-indigo-500"
          >
            <option value="typescript">TypeScript</option>
            <option value="python">Python</option>
            <option value="rust">Rust</option>
            <option value="go">Go</option>
            <option value="cpp">C++</option>
          </select>
        </div>
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="flex-1 bg-transparent p-6 mono text-sm outline-none resize-none text-slate-300 leading-relaxed"
          spellCheck={false}
        />
        <div className="p-4 border-t border-white/5 flex gap-4">
          <button 
            onClick={handleAnalyze}
            disabled={loading}
            className="flex-1 py-3 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 font-bold hover:bg-indigo-600/30 transition-all disabled:opacity-50"
          >
            Analyze Code
          </button>
          <button 
            onClick={handleOptimize}
            disabled={loading}
            className="flex-1 py-3 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 font-bold hover:bg-purple-600/30 transition-all disabled:opacity-50"
          >
            Optimize
          </button>
        </div>
      </div>

      <div className="glass rounded-3xl border-white/10 overflow-hidden flex flex-col h-[600px] bg-slate-900/40">
        <div className="px-6 py-4 bg-white/5 border-b border-white/5 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.8)]"></div>
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-widest">Gemini Engine Output</h3>
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-12 h-12 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-slate-500 mono text-sm">Processing code vectors...</p>
            </div>
          ) : result ? (
            <div className="prose prose-invert max-w-none text-slate-300 text-sm md:text-base whitespace-pre-wrap mono">
              {result}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
              <svg className="w-16 h-16 mb-4 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <p className="text-slate-400">Ready for processing.<br/>Paste code to begin analysis.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
