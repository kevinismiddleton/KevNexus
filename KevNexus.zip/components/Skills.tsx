
import React from 'react';

const skills = [
  { category: "Cloud Architecture", items: ["AWS (SA Pro)", "Kubernetes", "Terraform", "Serverless"] },
  { category: "Core Engineering", items: ["Rust", "Go", "C++", "Java (Spring)"] },
  { category: "Web Ecosystem", items: ["React / Next.js", "TypeScript", "Tailwind CSS", "Node.js"] },
  { category: "Intelligence", items: ["Vector DBs", "LLM Fine-tuning", "PyTorch", "Data Science"] }
];

const Skills: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold mb-4 tracking-tight">Engineering <span className="gradient-text">DNA</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto">Mastery over the modern stack, from the silicon level to the cloud orchestration layer.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {skills.map((skillGroup, idx) => (
          <div key={idx} className="glass p-8 rounded-3xl border-white/5 hover:bg-white/[0.03] transition-colors">
            <h3 className="text-lg font-bold mb-6 text-indigo-400">{skillGroup.category}</h3>
            <ul className="space-y-4">
              {skillGroup.items.map(item => (
                <li key={item} className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-600"></div>
                  <span className="text-slate-300 font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      
      <div className="mt-20 p-10 glass rounded-[2rem] border-white/10 flex flex-col md:flex-row items-center justify-between gap-10">
        <div className="flex-1">
          <h3 className="text-2xl font-bold mb-4">Ready to build something <span className="text-indigo-400 underline decoration-indigo-500/30 underline-offset-8">revolutionary?</span></h3>
          <p className="text-slate-400">I'm currently open to new architectural challenges and high-impact engineering roles.</p>
        </div>
        <div className="flex gap-4">
          <a href="mailto:kevin@devnexus.io" className="px-8 py-4 bg-indigo-600 rounded-2xl font-bold hover:bg-indigo-500 transition-all shadow-[0_0_20px_rgba(79,70,229,0.3)]">
            Start Conversation
          </a>
        </div>
      </div>
    </div>
  );
};

export default Skills;
